package que5;
//Mohammed Shamsul arefeen, 104707638
//This program is an infinite loop, intentionally made to try out multiple combinations of numbers.
import java.util.Scanner;

public class Min3 {

	
	public static float minimum3(float a, float b, float c){
		
		return Math.min(a, Math.min(b, c));
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan= new Scanner(System.in);
		while(true){
		System.out.println("This program calculates the smallest of three numbers. ");
		System.out.println("Enter the first number: ");
		float first = scan.nextFloat();
		System.out.println("Enter the second number: ");
		float second = scan.nextFloat();
		System.out.println("Enter the third number: ");
		float third = scan.nextFloat();
		
		System.out.println("The smallest number of the three is: "+minimum3(first, second, third));
		}
		
		
	}

}
