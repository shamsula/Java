package que6;
import java.util.Random;
//Mohammed Shamsul Arefeen, 104707638
import java.util.Scanner;

public class NumberGuessGame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Random rand = new Random();
		Scanner scan= new Scanner(System.in); 
		int option = 1;
		while(option!=2){
		System.out.println("This is the number guessing game\nGuess a number between 1 and 1000");
		int random = rand.nextInt(1000)+1;
		System.out.println("the number is "+random);
		int guess=0;
		Boolean right = false;
		while(!right){
			
			System.out.println("Enter your guess (1-1000): ");
			guess = scan.nextInt();
			if(guess>random){
				System.out.println("Too high. try again!");
			}
			else if(guess<random){
				System.out.println("Too low. try again!");
			}
			
			else if(guess==random){
				System.out.println("Congratulations! You guessed the number! Enter 1 to start again or 2 to end game: ");
				option=scan.nextInt();
				right = true;
				
			}
			
		}
		
	}

}
}
