package que4;
//Mohammed Shamsul Arefeen, 104707638
import java.util.Scanner;

public class SquarePrinter {

	public static void squareOfAsterisks(int side ){
		
		for(int i=0;i<side;i++){
			for(int j=0;j<side;j++){
				System.out.print('*');
			}
			System.out.println("");
		}
			
	}
	
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	Scanner scan = new Scanner(System.in);
	
	System.out.println("Enter the size of the side of the square: ");
	int side = scan.nextInt();
	System.out.println("Printing square of size: "+side+"\n\n");
	squareOfAsterisks(side);
	
	}

}
