package que3;

import java.util.Scanner;

public class Fraction_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		
		System.out.println("Enter the numerator");
		int nume= scan.nextInt();
		System.out.println("Enter the denominator");
		int denume= scan.nextInt();
		
		Fraction frac = new Fraction(nume, denume);
		
		int option= -1;
		
		while(option!=9){
			
			System.out.println("Enter 1. to reset numerator, 2. to reset denominator, 3 to display fraction, 9 to exit: ");
			option = scan.nextInt();
			
			if(option==1){
			   System.out.println("Enter new numerator: ");
			   nume=scan.nextInt();
			   frac.setNumerator(nume);
			}
			
			if(option==2){
				System.out.println("Enter the new denominator: ");
				denume=scan.nextInt();
				frac.setDenominator(denume);
			}
			if(option==3){
				frac.displayFrac();
			}
		}
		
	}

}
