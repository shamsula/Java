package que3;
//Mohammed Shamsul Arefeen, 104707638
public class Fraction {

	private int numerator;
	private int denominator;
	
	public Fraction(int nume, int denume){
		this.numerator=nume;
		this.denominator=denume;
		lowestFrac();
		
	}
	
	public void setNumerator(int nume){
		this.numerator=nume;
		lowestFrac();
	}
	public void setDenominator(int denomi){
		this.denominator=denomi;
		lowestFrac();
	}
	
	public Double getFraction(){
		
		
		return (double) (numerator/denominator);
	}
	
	public int GCD(int num, int denum){
		
		if(denum==0){
			return num;
		}
		
		return GCD(denum, num%denum);
	}
	
	
	public void lowestFrac(){
		
		int gcd = GCD(numerator,denominator);
		this.numerator=numerator/gcd;
		this.denominator=denominator/gcd;
		
	}
	
	public void displayFrac(){
		System.out.println("The simplest fraction is : "+this.numerator+" / "+this.denominator);
		
	}
	
	
}
