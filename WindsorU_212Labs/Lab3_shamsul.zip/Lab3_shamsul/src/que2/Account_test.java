package que2;
import java.util.*;

public class Account_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your name: ");
		String name= scan.nextLine();
		System.out.println("Enter your address (in one line): ");
		String addr= scan.nextLine();
		System.out.println("Enter your SIN number: ");
		int SIN= scan.nextInt();
		
		
		Account acc1 = new Account(SIN,name,addr);
		System.out.println("Account created!");
		int ans=0;
		while(ans!=9){
			System.out.println("\nChoose your action\n1 for Deposit. 2 for Withdrawl. \n3 to change phone number.\n4 to change email"
					+"\n5 to show account information"+ " 9 to exit the menu: ");
			ans=scan.nextInt();
			if(ans==1){
				System.out.println("Enter amount to deposit: ");
				double amt=scan.nextDouble();
				acc1.deposit(amt);
			}
			if(ans==2){
				System.out.println("Enter amount to withdraw: ");
				double amt1=scan.nextDouble();
				acc1.withdraw(amt1);
			}
			if(ans==3){
				System.out.println("Enter the phone number: ");
				int pnum=scan.nextInt();
				acc1.setPhone(pnum);
				System.out.println("new phone number is: "+acc1.getPhoneNO());
			}
			if(ans==4){
				System.out.println("Enter the email: ");
				String email= scan.nextLine();
				acc1.setEmail(email);
				System.out.println("new phone number is: "+acc1.getEmail());
			}
			if(ans==5){
				acc1.displayInfo();
			}
			
		}
	}

}
