package que2;
import java.util.Random;;
//Mohammed Shamsul Arefeen, 104707638
public class Account {
	
	private int SIN,phone=0;
	double balance=0;
	String name, address, acc_no,email="N/A";
	
	
	public Account(int s, String n, String add){
		
		SIN=s;
		name=n;
		address=add;
		Random rand= new Random();
		acc_no = Integer.toString(s)+ Integer.toString((int)rand.nextInt(9000)+1000);  //creates account number for client 
		
		
	}
	
	public void displayInfo(){
		System.out.println("Account info\nName: "+this.getName()+
				"Account number: "+this.getAccNO()+"\nSIN: "+this.getSIN()+"\nAddress: "+this.getAddress()+"\nBalance: "+this.getBalance());
	}
	
	public int getSIN(){
		return SIN;
	}
	
	public int getPhoneNO(){
		if(phone==0)
		{System.out.println("Phone number not available");
			return -1;
		}
		else return phone;
	}
	
	public String getName(){
		return name;
	}
	
	public String getAddress(){
		return address;
	}
	
	public double getBalance(){
		return balance;
	}
	
	public String getAccNO(){
		return acc_no;
	}
	
	public String getEmail(){
		return email;
	}
	
	public void setName(String nam){
		
		name =nam;
	}
	
	public void setAddress(String add){
		address=add;
	}
	
	public void setPhone(int num){
		phone=num;
	}
	
	public void setEmail(String EM){
		email=EM;
	}
	
	public void withdraw(double amt){
		if(balance==0){
			System.out.println("Bank balance is 0. Money Cannot be withdrawn. ");
			
		}
		
		else if((balance-amt<0)){
			System.out.println("Withdraw amount exceeded by "+(balance-amt)+". Enter a lesser amount to be withdrawn");
		}
		else {
			balance = balance-amt;
			
		}
		System.out.println("New Balance is: "+balance);
	}
	
	public void deposit(double amt){
		balance+=amt;
		System.out.println("Deposit Successful! New Balance is: "+balance);
	}
	
	

}
