package que7;

import java.util.Random;

public class Complex{

	private float realPart;
	private float imaginaryPart;
	//private float i = (float)Math.sqrt(-1);
	
	public Complex(float real, float imagine){
		this.realPart= real;
		this.imaginaryPart=imagine;
	}
	
	public Complex(){
		
		Random rand = new Random();
		this.realPart= rand.nextInt(100)+1;
		this.imaginaryPart = rand.nextInt(100)+1;
	}
	
	public void printNumbers(){
		System.out.println("("+this.realPart+", "+this.imaginaryPart+"i) ");
	}
	
	public float getReal(){
		return this.realPart;
	}
	
	public float getImaginary(){
		return this.imaginaryPart;
	}
	
	public void addComplex(Complex a, Complex b){
		Complex temp = new Complex((a.getReal()+b.getReal()),(a.getImaginary()+b.getImaginary()));
		//Complex too= Complex();
		this.realPart=(a.getReal()+b.getReal());
		this.imaginaryPart=(a.getImaginary()+b.getImaginary());
	}
	
	public void subtractComplex(Complex a, Complex b){
		
		Complex temp = new Complex((a.getReal()-b.getReal()),(a.getImaginary()-b.getImaginary()));
		this.realPart=(a.getReal()-b.getReal());
		this.imaginaryPart=(a.getImaginary()-b.getImaginary());
		
	}
	
}
