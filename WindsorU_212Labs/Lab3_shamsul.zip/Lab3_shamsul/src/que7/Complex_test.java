package que7;
//Mohammed Shamsul Arefeen. 104707638
import java.util.Scanner;

public class Complex_test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		Scanner scan = new Scanner(System.in);
		float rFirst, iFirst, rSecond, iSecond;
		System.out.println("Enter the real part of the first complex number: ");
		rFirst=scan.nextFloat();
		System.out.println("Enter the imaginary part of the first complex number: ");
		iFirst=scan.nextFloat();
		System.out.println("Enter the real part of the first complex number: ");
		rSecond=scan.nextFloat();
		System.out.println("Enter the imaginary part of the second complex number: ");
		iSecond=scan.nextFloat();
		
		Complex a= new Complex(rFirst,iFirst);
		Complex b= new Complex(rSecond,iSecond);
		
		Complex add= new Complex();
		add.addComplex(a, b);
		
		Complex sub = new Complex();
		sub.subtractComplex(a, b);
		
		System.out.print("Adding the first complex to the second complex number gives: ");
		add.printNumbers();
		System.out.print("\nSubtracting the second imaginary number from first gives: ");
		sub.printNumbers();
		
		
	}

}
