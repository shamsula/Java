package que1;

public class Date_Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Date d1 = new Date(26,5,99);  //Enter Dates to modify d1,d2,d3
		Date d2 = new Date(8,6,94);
		Date d3 = new Date(15,3,00);
		
		Date d4= new Date(26,05,99); // Enter Date to modify Date object 4
		
		
		System.out.println("The date of d4 is "+d4.toString());
		
		if(d4.LessThan(d1))               // Compare 3 
			System.out.println("d4 is less than d1");  
		else 
			System.out.println("d4 is greater than d1");
		
		if(d4.LessThan(d2))  //compare 2
			System.out.println("d4 is less than d2");
		else 
			System.out.println("d4 is greater than d2");
		
		if(d4.LessThan(d3))  //compare 3
			System.out.println("d4 is less than d3");
		else 
			System.out.println("d4 is greater than d3");
		
	
		
		
	}

}
