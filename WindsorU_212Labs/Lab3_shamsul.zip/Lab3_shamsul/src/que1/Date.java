package que1;
//Mohammed Shamsul Arefeen, 104707638
public class Date {

	
private int day, month, year;




public Date( int  d, int mo, int y){
	day=d;
	month=mo;
	year=y;
}


public int getDay(){
	return day;
}

public int getMonth(){
	return month;
}

public String getMonthInWords(){
	switch (month){
	case 1: return "Jan";
	case 2: return "feb";
	case 3: return "Mar";
	case 4: return "Apr";
	case 5: return "May";
	case 6: return "Jun";
	case 7: return "Jul";
	case 8: return "Aug";
	case 9: return "Sep";
	case 10: return "Oct";
	case 11: return "Nov";
	case 12: return "Dec";
	default : return "invalid";
	}
	
}

public int getYear(){
	return year;
}

public void setDay(int d){
	day=d;
}

public void setMonth(int m){
	month=m;
}

public void setYear(int y){
	year=y;
}



public String toString(){
	//char[] newDate= year.toCharArray();
	return  getMonthInWords() +" "+day+", '"+ year;
}

public Boolean LessThan(Date d2){
	if(d2.getYear()>=50){
		if(this.getYear()>=50){
			
			if(d2.getYear()>this.getYear())
				return true;
			else if(d2.getYear()==this.getYear()){
				if(this.getMonth()<d2.getMonth())
					return true;
				else if(this.getMonth()==d2.getMonth())
					if(this.getDay()<d2.getDay())
						return true;
				
				//else return false;
			}
		}
		else if(this.getYear()<50)
			return false;
	}
	else if(d2.getYear()<50){
			if(this.getYear()<50){
				if(d2.getYear()<this.getYear())
					return true;
				
				else if(d2.getYear()==this.getYear()){   //if year is same
					if(this.getMonth()<d2.getMonth())
						return true;
					else if(this.getMonth()==d2.getMonth())
						if(this.getDay()<d2.getDay())
							return true;
					
					//else return false;
				}
				
			}
			else if(this.getYear()>50)
				return true;
			//else return false;
	}
	
	 return false;
}

}
