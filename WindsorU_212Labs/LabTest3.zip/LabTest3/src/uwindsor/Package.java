/*
 * Author: Saurabh Joshi (joshio@uwindsor.ca)
 * Package is the base class to calculate shipping cost.
 */
package uwindsor;

public class Package {
	
	private double weightOunces;	//Package weight
	private double shippingCost;	//Total shipping cost
	private char shippingMethod;	//Shipping method
	
	// Constructor
	public Package(double weightOunces, char shippingMethod) {
		this.weightOunces = weightOunces;
		this.shippingMethod = shippingMethod;
		
		calculateCost();
	}
	
	//Method to calculate the cost
	private void calculateCost() {
		switch(shippingMethod) {
			case 'A': 
				if(weightOunces < 8) 
					shippingCost = 2.00;
				else if ((weightOunces >= 9) && (weightOunces <= 16)) 
					shippingCost = 3.00;
				else 
					shippingCost = 4.50;
				break;
			case 'T':
				if(weightOunces < 8) 
					shippingCost = 1.50;
				else if ((weightOunces >= 9) && (weightOunces <= 16)) 
					shippingCost = 2.35;
				else 
					shippingCost = 3.25;
				break;
			case 'M':
				if(weightOunces < 8) 
					shippingCost = 0.50;
				else if ((weightOunces >= 9) && (weightOunces <= 16)) 
					shippingCost = 1.50;
				else 
					shippingCost = 2.15;
				break;
			default: shippingCost = 0; 
		}
	}
	
	//Method to change the shipping method and recalculate the cost.
	public void changeShippingMethod(char newShippingMethod) {
		this.shippingMethod = newShippingMethod;
		calculateCost();
	}
	
	public double getWeightOunces() {
		return this.weightOunces;
	}
	
	public double getShippingCost() {
		return this.shippingCost;
	}
	
	public char getShippingMethod() {
		return this.shippingMethod;
	}
	
	public void display() {
		// Display data as Shipping method	Weight(oz.)	Shipping cost
		System.out.println(shippingMethod + "\t\t| " + weightOunces + "\t\t| " + shippingCost);
	}
	
}