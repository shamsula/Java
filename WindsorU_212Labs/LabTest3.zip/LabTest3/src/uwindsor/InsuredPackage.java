/*
 * Author: Saurabh Joshi (joshio@uwindsor.ca)
 * InsuredPackage extends the Package class and calculates the
 * insurance and adds it to the total cost.
 */
package uwindsor;

public class InsuredPackage extends Package {

	private double additionalCost;
	private double totalCost;
	
	public InsuredPackage(double weightOunces, char shippingMethod) {
		//Call super class constructor
		super(weightOunces, shippingMethod);
		
		calculateCost();
	}

	//Override method to add insurance cost
	private void calculateCost() {
		//Get cost without insurance from the super class
		double cost = super.getShippingCost();
		
		if(cost < 1.0) 
			this.additionalCost = 2.45;
		else if (cost > 1.0 && cost < 3.0) 
			this.additionalCost = 3.95;
		else 
			this.additionalCost = 5.55;
		
		//Add insurance to the total cost
		this.totalCost = this.additionalCost + cost;
	}
	
	//Override changeShippingMethod to add insurance cost to the recalculated cost
	public void changeShippingMethod(char newShippingMethod) {
		super.changeShippingMethod(newShippingMethod);
		calculateCost();
	}
	
	
	
	public void display() {
		// Display data as Shipping method	Weight(oz.)	Shipping cost	Additional cost	Total cost
		System.out.println(super.getShippingMethod() + "\t\t| " + super.getWeightOunces() + "\t\t| " + super.getShippingCost() + "\t\t| " + this.additionalCost + "\t\t| " + this.totalCost);
	}
	
}
