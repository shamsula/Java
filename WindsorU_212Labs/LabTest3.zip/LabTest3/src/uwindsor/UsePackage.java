/*
 * Author: Saurabh Joshi (joshio@uwindsor.ca)
 * UsePackage class tests the Package and InsuredPackage classes.
 */
package uwindsor;

public class UsePackage {

	public static void main(String args[]){
		Package one = new Package(17.2d, 'A');
		Package two = new Package(10.0d, 'T');
		Package three = new Package(19.4d, 'M');
		
		System.out.println("\n\nShipping method\t| Weight(oz.)\t| Shipping cost");
		one.display();
		two.display();
		three.display();
		
		three.changeShippingMethod('A');
		three.display();
		
		InsuredPackage four = new InsuredPackage(5.2d, 'M');
		InsuredPackage five = new InsuredPackage(10.3d, 'T');
		InsuredPackage six = new InsuredPackage(17.2d, 'A');
		
		
		System.out.println("\n\nShipping method\t| Weight(oz.)\t| Shipping cost\t| Insurance cost\t| Total cost");
		four.display();
		five.display();
		six.display();
		
		six.changeShippingMethod('T');
		six.display();
	}
	
	
}
