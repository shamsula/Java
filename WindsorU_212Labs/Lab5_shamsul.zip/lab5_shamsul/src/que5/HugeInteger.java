package que5;
import java.math.*;

public class HugeInteger {

	private int[] huge = new int[40];
	private int size=0;
	private byte[] arr = new byte[40];
	BigInteger[] big = new BigInteger[40];
	
	
	public HugeInteger(){};
	
	public void parse(String str){
		
		String s;
		int m=0;
		size=str.length();
		
		for(int n =40-str.length(); m<str.length();n++,m++){
			s=Character.toString(str.charAt(m));
			huge[n]=Integer.parseInt(s);
			
			
		}
	}
	
	public String toString(){
		
		String s="";
		for(int n=40-size; n<40;n++){
			s= s+ huge[n];
		}
		return s;
	}
	
	public void add(String a){
		String s;
		
		int neww= Integer.parseInt(this.toString()) + Integer.parseInt(a);
		
		s= Integer.toString(neww);
		this.parse(s);
	}
	
	public  void subtract(String a){
		String s;
		
		int neww= Integer.parseInt(this.toString()) - Integer.parseInt(a);
		
		s= Integer.toString(neww);
		this.parse(s);
	}
	
	public Boolean isEqualtTo(HugeInteger h){
		if(this.toString().equals(h.toString()))
			return true;
		else return false;
	}
	
	public Boolean isNotEqualTo(HugeInteger h){
		if(this.toString().equals(h.toString()))
			return false;
		else return true;
	}
	
	public Boolean isGreaterThan(HugeInteger h){
		Boolean r = false;
		if(!this.isEqualtTo(h)){
			
			//convert both of them to integers and do it 
		int thisOne= Integer.parseInt(this.toString());
		int thatOne= Integer.parseInt(h.toString());
		if(thisOne>thatOne)
			r = true;
		}
		return r;
	}
	
	public Boolean isLessThan(HugeInteger h){
		Boolean r = false;
		if(!this.isEqualtTo(h)){
			
			//convert both of them to integers and do it 
		int thisOne= Integer.parseInt(this.toString());
		int thatOne= Integer.parseInt(h.toString());
		if(thisOne<thatOne)
			r = true;
		}
		return r;
	}
	
	
	
}
