package que5;

import java.util.Scanner;

public class HugeInteger_Tester {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		HugeInteger h = new HugeInteger();
		HugeInteger j = new HugeInteger();
		
		
		System.out.println("Enter the HUGE integer you want to store ");
		
		String s = scan.nextLine();
		
		h.parse(s);
		
		System.out.println("The huge integer stored is: "+h.toString());
		
		System.out.println("Enter an integer to add to it: ");
		
		s= scan.nextLine();
		
		h.add(s);
		
		System.out.println("New integer is: "+h.toString());
		
		System.out.println("Enter an integer to subtract from it: ");
		
		s= scan.nextLine();
		
		h.subtract(s);
		
		System.out.println("New integer is: "+h.toString());
		
		System.out.println("Enter another HUGE integer you want to store ");
		
		 s = scan.nextLine();
		
		j.parse(s);
		
		if(h.isEqualtTo(j))
			System.out.println("Both the Huge integer objects are equal");
		else if(h.isNotEqualTo(j))
			System.out.println("Both the Huge integer objects are NOT equal");
		
		if(j.isGreaterThan(h))
			System.out.println("second object greater than first");
		else  if(j.isLessThan(h))
			System.out.println("second object smaller than first");
		
		
	}

}
