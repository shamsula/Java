package que4;

import java.util.Random;

public class DiceROLLAYEEE {

	
	public static int Dice(){
		
		Random rand= new Random();
		
		return (rand.nextInt(6)+1)+(rand.nextInt(6)+1);
	}
	
	public static void main(String[] args) {
		
		int[] dice = new int[13];
		
		for(int x = 0; x<36000000; x++){
		   dice[Dice()]++;
		}
		
		System.out.println("The results are tabulated below");
		for(int x=2;x<13;x++){
			System.out.println(x+": "+dice[x]);
		}

		
	}

}
