package que2;

import java.util.Scanner;

public class ExpoRecurse2 {
	
	
	public static int power(int base, int exponent){
		
		if(exponent==1)						//base case
			return base;
		
		else if(exponent%2==0){
			//return  power(base, exponent/2) * power(base, exponent/2);
			if(exponent==2) return base*base;
			
			else return power( power(base, exponent/2), 2);
		}
		else 
		{
			return base* power(base, exponent-1);
		}
	}
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number you want to find the exponent of: ");
		
		int base = scan.nextInt();
		
		System.out.println("What is the power of the exponent: ");
		
		int expo = scan.nextInt();
		
		System.out.println(base+" to the power of "+expo+" equals: "+power(base,expo));
	}

}
