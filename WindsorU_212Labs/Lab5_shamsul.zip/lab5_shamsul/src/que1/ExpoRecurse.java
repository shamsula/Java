package que1;

import java.util.Scanner;

public class ExpoRecurse {
	
	
	public static int power(int base, int exponent){
		
		if(exponent==1)						//base case
			return base;
		
		else 
		{
			return base* power(base, exponent-1);
		}
	}
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the number you want to find the exponent of: ");
		
		int base = scan.nextInt();
		
		System.out.println("What is the power of the exponent: ");
		
		int expo = scan.nextInt();
		
		System.out.println(base+" to the power of "+expo+" equals: "+power(base,expo));
	}

}
