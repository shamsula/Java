package que3;

import java.util.Scanner;

public class GCDRecurse {

	
	
	public static int gcd(int x, int y){
		if(y==0)
			return x;
		
		else return gcd(y, x%y);
		
	}
	
	public static void main(String[] args) {
		
		Scanner scan = new Scanner (System.in);
		
		System.out.println("Enter the first number: ");
		
		int x = scan.nextInt();
		
		System.out.println("Enter the second number: ");
		
		int y = scan.nextInt();
		
		System.out.println("The GCD of "+x+" and y is "+gcd(x,y));
		
	}
}
