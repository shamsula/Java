package que3;

import java.util.Date;

public abstract class GeometricObject {
	
private String color;	
private Boolean filled;
private Date dateCreated;

GeometricObject (){
	this.color="white";
	this.filled=false;
	this.dateCreated=new Date();
}

public String getColor(){
	return this.color;
}

public void setColor(String c){
		this.color=c;
}

public Boolean isFilled(){
	return filled;
}

public void setFilled(Boolean f){
	this.filled=f;
}

public Date getDateCreated(){
	return this.dateCreated;
}

public String toString(){
	String s= "color: "+this.color;
	
	if(filled) s+="\nis Filled"; else s+="\nis not Filled";
	
	return s+"\nDate is: "+this.getDateCreated();
}

public  abstract double getArea();

public abstract double getPerimeter();

}
