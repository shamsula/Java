package que3;

public class Test3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Triangle t1 = new Triangle();
		
		System.out.println(t1.toString()+"\n");
		
		Triangle t2 = new Triangle(3,5,4);
		
		System.out.println(t2.toString()+"\n");
		
		System.out.println("The perimeter of t2 is: "+t2.getPerimeter()+" and its area is: "+t2.getArea());
	}

}
