package que2;

public class Test2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee E1 = new Employee("James",60000.00);
		Manager M1 = new Manager("Bob",80000.00,"Engineering");
		Executive Ee1 = new Executive ("Dylan",90000.00,"HR");
		
		System.out.println("Employee "+E1.toString()+"\n");
		
		System.out.println("Manager "+M1.toString()+"\n");
		
		System.out.println("Executive "+Ee1.toString()+"\n");
		
		M1=Ee1;
		
		System.out.println("Manager "+M1.toString()+"\n");
		
		E1=M1;
		
		System.out.println("Employee "+E1.toString()+"\n");
		
	}

}
