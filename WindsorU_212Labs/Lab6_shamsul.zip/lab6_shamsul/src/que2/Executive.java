package que2;

public class Executive extends Manager{

	Executive( String name, double Salary, String Department ){
		super(name, Salary,Department);
	}
	
	public String toString(){
		return super.toString();
	}
}
