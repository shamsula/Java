package que2;

public class Employee {

	public String name;
	public double salary;
	
	Employee(String name, double salary){
		this.name=name;
		this.salary=salary;
	}
	
	public String toString(){
		return name+"\n"+salary;
	}
}
