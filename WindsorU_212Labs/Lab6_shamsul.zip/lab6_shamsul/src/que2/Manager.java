package que2;

public class Manager extends Employee{

	private String department;
	
	Manager(String name, double salary,String department){
		super(name,salary);
		this.department=department;
	}
	

	public String toString(){
		return super.toString()+"\n"+department;
	}
}
