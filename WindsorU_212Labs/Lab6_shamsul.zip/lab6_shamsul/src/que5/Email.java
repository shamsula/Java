package que5;

public class Email extends Document{

	private String sender;
	private String recipient;
	private String title;
	
	Email(String txt, String sender,String recipient, String title) {
		super(txt);
		this.sender=sender;
		this.recipient=recipient;
		this.title=title;
		
	}
	
	public String getText(){
		return super.toString();
	}
	
	public String getSender(){
		return this.sender;
	}
	
	public void setSender(String s){
		this.sender=s;
	}
	
	public String getRecipient(){
		return this.recipient;
	}
	
	public void setRecipient(String s){
		this.recipient=s;
	}
	
	public String getTitle(){
		return this.title;
	}
	
	public void setTitle(String t){
		this.title=t;
	}
	
	public String toString(){
		return "Title: "+this.title+"\nRecipient:  "+this.recipient+"\nSender: "+this.sender+"\nBody: "+super.toString()+"\n";
	}

}
