package que5;

//Mohammed Shamsul Arefeen, 104707638

public class Test5 {
	
	public static boolean ContainsKeyword(Document docObject, String keyword){
		if (docObject.toString().indexOf(keyword,0) >= 0)
		return true ;
		return false ;
		}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub

			Email e1 = new Email("Hello, darling.","Jim Moriarty","Sherlock Holmes","Final Problem");
			
			System.out.println(e1.toString());
			
			if(ContainsKeyword(e1,"Moriarty"))
				System.out.println("We found Moriarty in Email e1!");
			
			e1.setSender("James Watson");
			if(!ContainsKeyword(e1,"Moriarty"))
				System.out.println("Oops, it was from Dr. Watson!\n\n");
			
			
			File f1 = new File("Hey, How do you do?","C:That\\this\\");
			
			System.out.println(f1.toString());
			
			if(ContainsKeyword(f1,"That"))
				System.out.println("We found the directory of the well wisher!");
			
			Document e2 = new Email("This is not a test","Guyver","James Bond","Warning");
			System.out.println("\n"+e2.toString());
			
			File f2 = new File("Cannot Load file","C:Here\\THere\\");
			e2=f2;
			System.out.println("\n"+e2.toString());
			
			
			
	}

}
