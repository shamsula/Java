package que5;

public class File extends Document {

	private String pathname;
	
	File(String txt,String pathname) {
		super(txt);
		this.pathname=pathname;
		
	}
	
	public String getPathname(){
		return this.pathname;
	}
	
	public void setPathname(String pathname){
		this.pathname=pathname;
	}
	
	public String getText(){
		return super.toString();
	}

	public String toString(){
		return this.pathname+"\n"+this.getText();
	}
}
