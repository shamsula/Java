package que5;

public class Document {

	private String text;
	
	Document(String txt){
		this.text=txt;
	}
	
	
	public void setText(String txt){
		this.text=txt;
	}
	
	public String toString(){
		return this.text;
	}
}
