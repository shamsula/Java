package que1;

public class Person {

private String name;

private int year;

Person( String name, int year){
	this.name=name;
	this.year=year;
}

public String toString(){
	return name+"\n"+year;
}
	
}
