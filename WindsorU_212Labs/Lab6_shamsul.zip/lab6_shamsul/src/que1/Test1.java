package que1;

//Mohammed Shamsul Arefeen, 104707638

public class Test1 {
	
	public static void main(String[] args) {
	Person P1 = new Person("Moe",2000);
	
	Student S1 = new Student("Joe", 1993, "CS");
	
	Instructor I1 = new Instructor ("Anderson", 1998,60000.00);
	
	Person S2 = new Student("Cole", 1993, "CS");
	
	System.out.println("Person "+P1.toString()+"\n");
	
	System.out.println("Student "+S1.toString()+"\n");
	
	System.out.println("Instructor "+I1.toString()+"\n");
	
	System.out.println("Person "+S2.toString()+"\n");
	
	}
	
}
