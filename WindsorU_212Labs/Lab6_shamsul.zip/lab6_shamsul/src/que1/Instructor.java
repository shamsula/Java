package que1;

public class Instructor extends Person{

	private double Salary;

	public Instructor(String name, int year, double Salary ){
		super(name,year);
		this.Salary=Salary;
	}
	
	public String toString(){
		return super.toString()+"\n"+this.Salary;
	}
}
