package que1;

public class Student extends Person {


	private String major;
	
	Student(String name, int year, String major) {
		super(name, year);
		this.major = major;
		// TODO Auto-generated constructor stub
	}

	public String toString(){
		return super.toString()+"\n"+major;
	}
}
