package que4;

public class Payment {

	private double amount; 
	
	Payment(double amt){
		this.amount=amt;
	}
	
	public double getAmount(){
		return this.amount;
	}
	
	public void setAmount(double amt){
		this.amount=amt;
		
	}
	
	public void paymentDetails(){
		System.out.println("The amount of payment is: "+this.amount);
	}
	
	
}
