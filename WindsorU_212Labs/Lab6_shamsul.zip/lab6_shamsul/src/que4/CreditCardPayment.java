package que4;

import java.text.SimpleDateFormat;
import java.util.Date;

public class CreditCardPayment extends Payment {
private Date date;
private String name;
private String ccNumber;

	CreditCardPayment(double amt, String name, Date date, String ccNumber){
		super(amt);
		this.name=name;
		this.date=date;
		this.ccNumber=ccNumber;
		
	}
	
	public String getName(){
		return this.name;
	}
	
	public Date getDate(){
		return this.date;
	}
	
	public String getCCnumber(){
		return this.ccNumber;
	}
	
	public void setName(String n){
		 this.name=n;
	}
	
	public void getDate(Date d){
		 this.date=d;
	}
	
	public void setCCnumber(String c){
		 this.ccNumber=c;
	}
	
	public void paymentDetails(){
		System.out.println("The name on credit card: "+this.name);
		System.out.println("The expiry date: "+new SimpleDateFormat("yyyy-MM-dd").format(this.date));
		System.out.println("The card number: "+this.ccNumber);
		System.out.println("The amount paid is: "+super.getAmount()+"\n");
	}
	
}
