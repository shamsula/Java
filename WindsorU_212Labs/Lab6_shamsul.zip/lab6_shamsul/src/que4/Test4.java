package que4;

//Mohammed Shamsul Arefeen, 104707638

import java.util.Date;
import java.text.DateFormat;

public class Test4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CashPayment cash = new CashPayment(100.00);
		
		cash.paymentDetails();
		
		CashPayment cash1 = new CashPayment(85.50);
		
		cash.setAmount(66.66);
		cash1.paymentDetails();
		Date d1 = new Date();
		d1.setDate(26); d1.setYear(118); 
		CreditCardPayment c1 = new CreditCardPayment(150.00,"Jim",d1, "65443199655");
		c1.paymentDetails();
		d1.setYear(119);;
		CreditCardPayment c2 = new CreditCardPayment(190.00,"Joe",d1, "65443199231");
		c2.paymentDetails();
		
	}

}
