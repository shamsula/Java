package que4;

public class CashPayment extends Payment {

	CashPayment(double amt) {
		super(amt);
		// TODO Auto-generated constructor stub
	}
	
	public void paymentDetails(){
		System.out.println("The amount of payment (in cash) is: "+super.getAmount()+"\n");
	}
	
	

}
